package handlers

import (
	"net/http"
)

func CreatePlaylistHandler(w http.ResponseWriter, r *http.Request) {

}

func DeletePlaylistHandler(w http.ResponseWriter, r *http.Request) {

}

func UpdatePlaylistHandler(w http.ResponseWriter, r *http.Request) {

}

func GetPlaylistInfoHandler(w http.ResponseWriter, r *http.Request) {

}