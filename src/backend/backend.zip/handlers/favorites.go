package handlers

import (
	"net/http"
)

func GetFavoritesHandler(w http.ResponseWriter, r *http.Request) {

}

func AddFavoriteHandler(w http.ResponseWriter, r *http.Request) {

}

func DeleteFavoriteHandler(w http.ResponseWriter, r *http.Request) {

}
