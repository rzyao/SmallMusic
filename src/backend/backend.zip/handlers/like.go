package handlers

import (
	"net/http"
)

func GetLikeHandler(w http.ResponseWriter, r *http.Request) {

}

func AddLikeHandler(w http.ResponseWriter, r *http.Request) {

}

func DeleteLikeHandler(w http.ResponseWriter, r *http.Request) {

}