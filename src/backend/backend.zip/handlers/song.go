package handlers

import (
	"net/http"
)

func GetSongInfoHandler(w http.ResponseWriter, r *http.Request) {

}
